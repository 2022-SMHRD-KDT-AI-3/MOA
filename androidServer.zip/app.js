let express = require("express");
let bodyparser = require('body-parser');
let app = express();
const session_mysql_save = require('express-mysql-session');

// 라우터를 사용하기위해 지정
let homeRouter = require("./routes/home");



app.use(bodyparser.urlencoded({extended:false}))
app.use("/home",homeRouter);
app.listen(3000, function(){console.log("start server");});    
