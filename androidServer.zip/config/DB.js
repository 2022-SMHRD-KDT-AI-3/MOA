const mysql = require('mysql');

let conn = mysql.createConnection({
    host: 'project-db-stu.ddns.net',
    user: 'MOA',
    password: '1234',
    port: '3307',
    database: 'MOA'
})

// let conn = mysql.createConnection({
//     host: '127.0.0.1',
//     user: 'root',
//     password: '1234',
//     port: '3306',
//     database: 'my_db'
// })

// DB연결 
conn.connect();



module.exports = conn;




