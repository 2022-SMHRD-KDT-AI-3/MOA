// express, router 
let express = require("express");
let router = express.Router();
let conn = require("../config/DB");
let s_id;
let p_id;


// 사용자 로그인 (login_senior)
router.post("/user_login",function(req,res){
    let S_ID = req.body.S_ID;
    let sql = "select * from MOA_USER where S_ID = ?";
    s_id = S_ID;
    
    conn.query(sql, [S_ID], function(err,rows){
        if(rows!=0){
            console.log("로그인 성공 : ",JSON.stringify(rows))
            res.send("로그인성공");
        }else{
            console.log("로그인 실패");
            res.send("로그인실패");
        }
    })
})

// 사용자 회원가입 (join_senior_phone)
router.post("/user_join",function(req,res){
    let S_NAME = req.body.S_NAME;
    let S_ID = req.body.S_ID;
    let S_BIRTH = req.body.S_BIRTH;
    let S_PHONE = req.body.S_PHONE;

    let sql = "insert into MOA_USER values(?,?,?,?);"

    conn.query(sql, [S_ID,S_NAME ,S_PHONE, S_BIRTH], function(err, rows){
        if(rows!=null){
            res.send("사용자회원가입 성공!");
            console.log("사용자회원가입 성공");
        }else{
            res.send("사용자 회원가입 실패!");
            console.log("사용자 회원가입 실패");
        }
    })
})

// 관리자 회원가입 (join_admin)
router.post("/admin_join", function(req,res){
    let a_id = req.body.a_id;
    let a_pw = req.body.a_pw;
    let a_name = req.body.a_name;
    let a_phone = req.body.a_phone;
    let a_birth = req.body.a_birth; // birth
    let sql = "insert into MOA_PROTECTOR values(?,?,?,?,?)";

    conn.query(sql, [a_id, a_pw, a_name, a_phone, a_birth],function(err, rows){
        if(rows!=null){
            res.send("성공");
            console.log(rows);
        }else{
            res.send("실패");
            console.log(err);
        }
    })  
})

// 관리자 로그인 (login_admin)
router.post("/admin_login",function(req,res){
    let a_id = req.body.a_id;
    let a_pw = req.body.a_pw;
    p_id = a_id;
    let sql = "select * from  MOA_PROTECTOR where a_id = ?  and  a_pw = ?"
    
    conn.query(sql, [a_id, a_pw], function(err,rows){
        if(rows!=0){
            console.log("로그인 성공")
            res.send("성공");
        }else{
            console.log("로그인 실패");
            res.send("실패");
        }
    })
})

// 가족추가하기(protector_tel)
router.post("/protector_tel", function(req,res){
    let S_ID = s_id;
    let FAMILY = req.body.FAMILY;
    let P_NAME = req.body.P_NAME;
    let F_PHONE = req.body.F_PHONE;
    let sql = "insert into PROTECTOR_TEL values(?,?,?,?)";

    console.log("보호자 아이디 : ",S_ID);
    console.log("보호자 타입 : ",FAMILY);
    console.log("보호자 이름 : ",P_NAME);
    console.log("보호자 번호 : ",F_PHONE);

    conn.query(sql, [S_ID,FAMILY,P_NAME,F_PHONE],function(err,rows){
        if (rows!=null){
            res.send("성공");
            console.log("성공"+rows);
        }else{
            res.send("실패");
            console.log("실패"+err);
        }
    })

})

// 사용자 추가
router.post("/matching",function(req,res){
    let s_name = req.body.search_name;
    var sql = "insert into MOA.moa_users_releation where s_name = ?"

    conn.query(sql, [s_name], function (err, rows) {
        console.log(rows);
        if (rows) {
            console.log("result : "+rows);
            res.status(200);
            res.send(200);
        }
        else return res.sendStatus(400);
      });
})


// 사용자 검색 
router.post("/userSearch", function(req, res){
    let s_name = req.body.search_name;
    var sql = "select * from MOA_USER where s_name = ?;"
    conn.query(sql, [s_name], function (err, rows) {
        console.log('결과',rows);
        if (rows) {
            console.log("result : "+rows);
            res.send(rows);
        }
        else return res.sendStatus(400);

      });

})

router.post("/TalkData",function(req,res){
    let s_id = req.body.s_id;
    let request = req.body.request;
    let response = req.body.response;
    let emotion = req.body.emotion;
    let date = req.body.date;

    console.log("들어옴??");
    console.log(s_id, request, response, emotion, date);

    let sql = "insert into TALKDATA values(?,?,?,?,?)";

    conn.query(sql,[s_id,date,request,response,emotion],function(err, rows){
        if(rows!=null){
            console.log("대화데이터 추가 성공");
            res.send("성공")
        }else{
            console.log("추가 실패");
            res.send("실패")
        }
    })

});







// https://github.com/2022-SMHRD-KDT-AI-3/moa.git
// https://github.com/kimchangheon73/moa_project.git





















module.exports = router;